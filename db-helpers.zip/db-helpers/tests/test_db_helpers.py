import pytest
from sqlalchemy import text

from db import config
from db.common import DatabaseConnectionError, mask, with_retry


@pytest.fixture(autouse=True)
def fresh_env(monkeypatch):
    """Clear cached settings/clients between tests."""
    import db.postgres as pg
    monkeypatch.setenv("DATABASE_URL", "sqlite:///:memory:")
    monkeypatch.setenv("DB_RETRIES", "2")
    config.get_settings.cache_clear()
    pg.get_engine.cache_clear()
    pg._session_factory.cache_clear()
    yield
    config.get_settings.cache_clear()
    pg.get_engine.cache_clear()
    pg._session_factory.cache_clear()


def test_settings_read_env(monkeypatch):
    monkeypatch.setenv("MONGO_DB", "custom")
    config.get_settings.cache_clear()
    assert config.get_settings().mongo_db == "custom"
    assert config.get_settings().retries == 2


def test_defaults_when_env_missing(monkeypatch):
    monkeypatch.delenv("REDIS_URL", raising=False)
    config.get_settings.cache_clear()
    assert config.get_settings().redis_url == "redis://localhost:6379/0"


def test_retry_succeeds_after_failures():
    calls = {"n": 0}

    def flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise ConnectionError("down")
        return "ok"

    assert with_retry("x", flaky, retries=3, delay=0) == "ok"


def test_retry_raises_clear_error():
    def bad():
        raise ConnectionError("nope")

    with pytest.raises(DatabaseConnectionError, match="Could not connect to x"):
        with_retry("x", bad, retries=2, delay=0)


def test_mask_hides_password():
    assert "secret" not in mask("postgresql://user:secret@host/db")


def test_engine_and_session_scope_commit_and_rollback():
    from db import get_engine, session_scope
    with get_engine().begin() as c:
        c.execute(text("CREATE TABLE t (id INTEGER)"))
    with session_scope() as s:
        s.execute(text("INSERT INTO t VALUES (1)"))
    with pytest.raises(RuntimeError):
        with session_scope() as s:
            s.execute(text("INSERT INTO t VALUES (2)"))
            raise RuntimeError("boom")
    with session_scope() as s:
        assert s.execute(text("SELECT COUNT(*) FROM t")).scalar() == 1


def test_unreachable_server_fails_fast_with_clear_error(monkeypatch):
    import db.redis_client as rc
    monkeypatch.setenv("REDIS_URL", "redis://127.0.0.1:1/0")
    monkeypatch.setenv("DB_CONNECT_TIMEOUT", "0.2")
    config.get_settings.cache_clear()
    rc.get_redis.cache_clear()
    with pytest.raises(DatabaseConnectionError):
        rc.get_redis()


def test_check_all_never_raises_and_reports_relational_ok(monkeypatch):
    from db import check_all
    for var, val in [("MONGO_URI", "mongodb://127.0.0.1:1"), ("REDIS_URL", "redis://127.0.0.1:1/0"),
                     ("ELASTICSEARCH_URL", "http://127.0.0.1:1"), ("NEO4J_URI", "bolt://127.0.0.1:1"),
                     ("DB_CONNECT_TIMEOUT", "0.2"), ("DB_RETRIES", "1")]:
        monkeypatch.setenv(var, val)
    config.get_settings.cache_clear()
    for mod, fn in [("db.mongo", "get_mongo_client"), ("db.redis_client", "get_redis"),
                    ("db.elastic", "get_elasticsearch"), ("db.neo4j_client", "get_neo4j_driver")]:
        getattr(__import__(mod, fromlist=[fn]), fn).cache_clear()
    out = check_all()
    assert out["relational"]["ok"] is True
    for name in ("mongodb", "redis", "elasticsearch", "neo4j"):
        assert out[name]["ok"] is False and out[name]["error"]
