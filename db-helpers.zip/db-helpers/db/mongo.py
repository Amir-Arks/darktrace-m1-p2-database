"""MongoDB (raw collected posts / documents)."""
from functools import lru_cache

from pymongo import MongoClient
from pymongo.database import Database

from .common import with_retry
from .config import get_settings


@lru_cache(maxsize=1)
def get_mongo_client() -> MongoClient:
    s = get_settings()
    timeout_ms = int(s.connect_timeout * 1000)

    def _connect():
        client = MongoClient(s.mongo_uri, serverSelectionTimeoutMS=timeout_ms,
                             connectTimeoutMS=timeout_ms)
        client.admin.command("ping")
        return client

    return with_retry("MongoDB", _connect, s.retries)


def get_mongo_db(name: str | None = None) -> Database:
    return get_mongo_client()[name or get_settings().mongo_db]
