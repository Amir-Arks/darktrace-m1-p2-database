"""Redis (cache, queues, rate limits)."""
from functools import lru_cache

import redis

from .common import with_retry
from .config import get_settings


@lru_cache(maxsize=1)
def get_redis() -> "redis.Redis":
    s = get_settings()

    def _connect():
        client = redis.Redis.from_url(
            s.redis_url, decode_responses=True,
            socket_connect_timeout=s.connect_timeout, socket_timeout=s.connect_timeout)
        client.ping()
        return client

    return with_retry("Redis", _connect, s.retries)
