import logging
import time
from typing import Callable, TypeVar

log = logging.getLogger("db")
T = TypeVar("T")


class DatabaseConnectionError(RuntimeError):
    """Raised when a database cannot be reached after all retries."""


def with_retry(name: str, fn: Callable[[], T], retries: int, delay: float = 0.5) -> T:
    """Run fn(); on failure retry with exponential backoff, then raise."""
    last: Exception | None = None
    for attempt in range(1, retries + 1):
        try:
            return fn()
        except Exception as exc:  # driver-specific errors differ, so catch broadly
            last = exc
            log.warning("%s connect failed (%d/%d): %s", name, attempt, retries, exc)
            if attempt < retries:
                time.sleep(delay * 2 ** (attempt - 1))
    raise DatabaseConnectionError(f"Could not connect to {name}: {last}") from last


def mask(url: str) -> str:
    """Hide passwords when logging URLs."""
    if "@" in url and "://" in url:
        scheme, rest = url.split("://", 1)
        return f"{scheme}://***@{rest.split('@', 1)[1]}"
    return url
