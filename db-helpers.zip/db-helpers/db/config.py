"""All connection settings come from environment variables (see .env.example)."""
import os
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class Settings:
    # Relational (alerts, watchlists, sources). Falls back to local SQLite for dev.
    database_url: str = "sqlite:///./dev.db"
    # Document store (raw collected posts)
    mongo_uri: str = "mongodb://localhost:27017"
    mongo_db: str = "darkweb"
    # Cache / queues
    redis_url: str = "redis://localhost:6379/0"
    # Search
    elasticsearch_url: str = "http://localhost:9200"
    elasticsearch_user: str = ""
    elasticsearch_password: str = ""
    # Graph (hacker profiling: usernames, wallets, posts)
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = ""
    # Shared
    connect_timeout: float = 5.0
    retries: int = 3


def _load() -> Settings:
    e = os.environ.get
    d = Settings()
    return Settings(
        database_url=e("DATABASE_URL", d.database_url),
        mongo_uri=e("MONGO_URI", d.mongo_uri),
        mongo_db=e("MONGO_DB", d.mongo_db),
        redis_url=e("REDIS_URL", d.redis_url),
        elasticsearch_url=e("ELASTICSEARCH_URL", d.elasticsearch_url),
        elasticsearch_user=e("ELASTICSEARCH_USER", d.elasticsearch_user),
        elasticsearch_password=e("ELASTICSEARCH_PASSWORD", d.elasticsearch_password),
        neo4j_uri=e("NEO4J_URI", d.neo4j_uri),
        neo4j_user=e("NEO4J_USER", d.neo4j_user),
        neo4j_password=e("NEO4J_PASSWORD", d.neo4j_password),
        connect_timeout=float(e("DB_CONNECT_TIMEOUT", d.connect_timeout)),
        retries=int(e("DB_RETRIES", d.retries)),
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return _load()
