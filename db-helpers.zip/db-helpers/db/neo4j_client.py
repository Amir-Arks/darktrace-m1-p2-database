"""Neo4j (graph of hacker usernames, wallets and posts)."""
from functools import lru_cache

from neo4j import GraphDatabase

from .common import with_retry
from .config import get_settings


@lru_cache(maxsize=1)
def get_neo4j_driver():
    s = get_settings()

    def _connect():
        driver = GraphDatabase.driver(
            s.neo4j_uri, auth=(s.neo4j_user, s.neo4j_password),
            connection_timeout=s.connect_timeout)
        driver.verify_connectivity()
        return driver

    return with_retry("Neo4j", _connect, s.retries)
