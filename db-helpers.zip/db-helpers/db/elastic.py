"""Elasticsearch (full-text search over collected content)."""
from functools import lru_cache

from elasticsearch import Elasticsearch

from .common import with_retry
from .config import get_settings


@lru_cache(maxsize=1)
def get_elasticsearch() -> Elasticsearch:
    s = get_settings()
    auth = (s.elasticsearch_user, s.elasticsearch_password) if s.elasticsearch_user else None

    def _connect():
        client = Elasticsearch(s.elasticsearch_url, basic_auth=auth,
                               request_timeout=s.connect_timeout)
        if not client.ping():
            raise ConnectionError("Elasticsearch ping returned False")
        return client

    return with_retry("Elasticsearch", _connect, s.retries)
