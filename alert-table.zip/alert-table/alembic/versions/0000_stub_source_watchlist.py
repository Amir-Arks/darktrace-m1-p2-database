"""STUB: minimal source + watchlist tables so the alert FKs can be tested alone.

DELETE THIS FILE when the real source/watchlist migrations are merged, and
set 0001's down_revision to the real latest revision.

Revision ID: 0000_stub
Revises:
"""
from alembic import op
import sqlalchemy as sa

revision = "0000_stub"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "source",
        sa.Column("source_id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(200), nullable=False),
    )
    op.create_table(
        "watchlist",
        sa.Column("watchlist_id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(200), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("watchlist")
    op.drop_table("source")
