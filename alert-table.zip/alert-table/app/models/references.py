"""
MINIMAL STAND-INS for tables owned by other team members.

The alert table has foreign keys to `source` and `watchlist`. These two
classes only exist so this branch can run and be tested on its own.
When the real Source / Watchlist models are merged:
  1. delete this file,
  2. change the import in app/models/__init__.py to the real models,
  3. delete alembic/versions/0000_stub_source_watchlist.py and point
     0001's down_revision at the real latest migration.
"""
from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class Source(Base):
    __tablename__ = "source"

    source_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)


class Watchlist(Base):
    __tablename__ = "watchlist"

    watchlist_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
