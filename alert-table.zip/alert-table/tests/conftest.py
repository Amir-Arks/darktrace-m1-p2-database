import pytest
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session

from app.models import Base, Source, Watchlist


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:")

    @event.listens_for(engine, "connect")
    def _fk_on(dbapi_conn, _):          # SQLite needs this to enforce foreign keys
        dbapi_conn.execute("PRAGMA foreign_keys=ON")

    Base.metadata.create_all(engine)
    with Session(engine) as s:
        s.add_all([
            Source(source_id=1, name="Forum A"),
            Source(source_id=2, name="Marketplace B"),
            Watchlist(watchlist_id=1, name="Bank credentials"),
            Watchlist(watchlist_id=2, name="Malware sales"),
        ])
        s.commit()
        yield s
    engine.dispose()
